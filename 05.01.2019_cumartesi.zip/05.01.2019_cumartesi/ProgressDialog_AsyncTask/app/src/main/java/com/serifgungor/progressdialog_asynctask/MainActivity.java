package com.serifgungor.progressdialog_asynctask;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.button);
        tv = findViewById(R.id.textView);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Download().execute();
            }
        });
    }

    private class Download extends AsyncTask{
        ProgressDialog dialog;
        @Override
        protected void onPreExecute() {
            //İşlem başlamadan önce
            dialog = new ProgressDialog(MainActivity.this);
            dialog.setTitle("Bekleyiniz");
            dialog.setMessage("İndirme işlemi gerçekleşiyor");
            dialog.show();
            super.onPreExecute();
            tv.setText("İşleme başlandı");
        }

        @Override
        protected void onPostExecute(Object o) {
            //İşlem tamamlandığında
            tv.setText("İşlem tamamlandı");
            dialog.dismiss(); //dialogu kapat
            super.onPostExecute(o);
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            // İşlemin gerçekleşme zamanı
            tv.setText("İşlem gerçekleşiyor");
            try {
                Thread.sleep(5000); //5sn beklet
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            return null;
        }
    }
}
