package com.serifgungor.retrofit_kullanimi.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.serifgungor.retrofit_kullanimi.Helper.ApiClient;
import com.serifgungor.retrofit_kullanimi.Model.Blog;
import com.serifgungor.retrofit_kullanimi.R;

import java.util.ArrayList;
import java.util.List;

public class BlogAdapter extends BaseAdapter {

    private List<Blog> blogs;
    private Context context;
    private LayoutInflater layoutInflater;

    public BlogAdapter(){

    }

    public BlogAdapter(Context context,List<Blog> blogs){
        this.blogs = blogs;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }



    @Override
    public int getCount() {
        return blogs.size();
    }


    @Override
    public Object getItem(int position) {
        return blogs.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.custom_blog_row,null);

        ImageView ivImage = v.findViewById(R.id.ivBlogPhoto);
        TextView tvTitle = v.findViewById(R.id.tvBlogTitle);
        TextView tvShareTime = v.findViewById(R.id.tvBlogShareTime);
        TextView tvViewCount = v.findViewById(R.id.tvBlogViewCount);

        Glide
                .with(v.getContext())
                .load(ApiClient.BASE_URL+blogs.get(position).getImage())
                .into(ivImage);
        tvTitle.setText(""+blogs.get(position).getBlog_seo_title());
        tvShareTime.setText(""+blogs.get(position).getSharetime());
        tvViewCount.setText(""+blogs.get(position).getBlog_do_viewcount());

        return v;
    }
}
