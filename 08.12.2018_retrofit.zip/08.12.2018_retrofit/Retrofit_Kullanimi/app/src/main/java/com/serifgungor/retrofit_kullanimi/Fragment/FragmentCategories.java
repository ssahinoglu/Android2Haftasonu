package com.serifgungor.retrofit_kullanimi.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.serifgungor.retrofit_kullanimi.Activity.WebActivity;
import com.serifgungor.retrofit_kullanimi.Adapter.BlogAdapter;
import com.serifgungor.retrofit_kullanimi.Adapter.CategoryAdapter;
import com.serifgungor.retrofit_kullanimi.Helper.ApiClient;
import com.serifgungor.retrofit_kullanimi.Interfaces.ApiInterface;
import com.serifgungor.retrofit_kullanimi.Model.Blog;
import com.serifgungor.retrofit_kullanimi.Model.BlogResponse;
import com.serifgungor.retrofit_kullanimi.Model.Category;
import com.serifgungor.retrofit_kullanimi.Model.CategoryResponse;
import com.serifgungor.retrofit_kullanimi.R;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentCategories extends Fragment {

    ListView listView;
    CategoryAdapter categoryAdapter;
    List<Category> categories;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_categories,null);

        listView = v.findViewById(R.id.listViewCategories);

        ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<CategoryResponse> call = apiInterface.getKategoriler("");

        call.enqueue(new Callback<CategoryResponse>() {
            @Override
            public void onResponse(Call<CategoryResponse> call, Response<CategoryResponse> response) {
                categories = response.body().getCategories();
                categoryAdapter = new CategoryAdapter(getContext(),categories);
                listView.setAdapter(categoryAdapter);
            }
            @Override
            public void onFailure(Call<CategoryResponse> call, Throwable t) {

            }
        });



        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent in = new Intent(getContext(),WebActivity.class);

                in.putExtra("url",ApiClient.BASE_URL+"category/"+categories.get(position).getCategory_link());

                startActivity(in);
            }
        });

        return v;

    }

}
