package com.serifgungor.retrofit_kullanimi.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.serifgungor.retrofit_kullanimi.Model.Category;
import com.serifgungor.retrofit_kullanimi.R;

import java.util.ArrayList;
import java.util.List;

public class CategoryAdapter extends BaseAdapter {
    private List<Category> categories;
    private Context context;
    private LayoutInflater layoutInflater;

    public CategoryAdapter(){

    }

    public CategoryAdapter(Context context,List<Category> categories){
        this.categories = categories;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        return categories.size();
    }
    @Override
    public Category getItem(int position) {
        return categories.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.custom_category_row,null);

        TextView tvTitle = v.findViewById(R.id.tvCategoryName);
        TextView tvCount = v.findViewById(R.id.tvCategoryBlogCount);

        Category c = getItem(position);
        tvTitle.setText(""+c.getCategory_name());
        tvCount.setText(""+c.getCnt());

        return v;
    }
}
