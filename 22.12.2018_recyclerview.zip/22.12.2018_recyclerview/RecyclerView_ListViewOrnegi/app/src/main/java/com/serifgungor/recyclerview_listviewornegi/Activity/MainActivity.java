package com.serifgungor.recyclerview_listviewornegi.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;

import com.serifgungor.recyclerview_listviewornegi.Adapter.ItemAdapter;
import com.serifgungor.recyclerview_listviewornegi.Model.Uyeler;
import com.serifgungor.recyclerview_listviewornegi.R;


import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;
    private ArrayList<Uyeler> uyeList;
    RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        uyeList = new ArrayList<>();
        listeyiDoldur(uyeList);

        recyclerView = (RecyclerView)findViewById(R.id.recycler_view);
        itemAdapter = new ItemAdapter(uyeList);
        mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);

        int resId = R.anim.layout_animation_fall_down;
        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(getApplicationContext(), resId);
        //recyclerView.setLayoutAnimation(animation);


        recyclerView.setAdapter(itemAdapter);
    }

    private void listeyiDoldur(ArrayList<Uyeler> uyeList){


        for(int i=0; i<250; i++){
            uyeList.add(new Uyeler("Şerif GÜNGÖR","contact@serifgungor.com","https://serifgungor.com/images/my-photo.jpg"));
        }

    }
}