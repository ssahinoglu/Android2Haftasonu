package com.serifgungor.recyclerview_listviewornegi.Holder;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.serifgungor.recyclerview_listviewornegi.R;

public class ItemHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    public TextView txtAd, txtEmail;
    public ImageView profilResim;

    @Override
    public void onClick(View v) {
        Toast.makeText(v.getContext(),"LOG "+getAdapterPosition(),Toast.LENGTH_LONG).show();
    }

    public ItemHolder(final View view) {
        super(view);
        txtAd = (TextView) view.findViewById(R.id.txtAd);
        txtEmail = (TextView) view.findViewById(R.id.txtEmail);
        profilResim = (ImageView) view.findViewById(R.id.profilResim);
        view.setOnClickListener(this);
    }
}