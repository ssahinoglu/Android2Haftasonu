package com.serifgungor.adsenseornegi.Activity;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

import com.serifgungor.adsenseornegi.Adapter.TabAdapter;
import com.serifgungor.adsenseornegi.Fragment.FragmentMain;
import com.serifgungor.adsenseornegi.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    TabLayout tabLayout;
    TabAdapter adapter;
    ViewPager viewPager;

    public void icerigiDegistir(Fragment fragment){
        /*
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction ft = fragmentManager.beginTransaction();
        ft.replace(R.id.frameLayout,fragment);
        ft.commit();
        */
    }

    public void tabEgitim(){
        List<Fragment> tabs = new ArrayList<>();

        FragmentMain f1 = new FragmentMain();
        Bundle b1 = new Bundle();
        b1.putString("title","Dil");
        f1.setArguments(b1);
        tabs.add(f1);

        FragmentMain f2 = new FragmentMain();
        Bundle b2 = new Bundle();
        b2.putString("title","Yazılım");
        f2.setArguments(b2);
        tabs.add(f2);

        FragmentMain f3 = new FragmentMain();
        Bundle b3 = new Bundle();
        b3.putString("title","Mesleki");
        f3.setArguments(b3);
        tabs.add(f3);

        FragmentMain f4 = new FragmentMain();
        Bundle b4 = new Bundle();
        b4.putString("title","Sınavlar");
        f4.setArguments(b4);
        tabs.add(f4);

        FragmentMain f5 = new FragmentMain();
        Bundle b5 = new Bundle();
        b5.putString("title","Üniversite");
        f5.setArguments(b5);
        tabs.add(f5);

        tablariUret(new String[]{"Dil","Yazılım","Mesleki","Sınavlar","Üniversite"},tabs);
    }

    public void tabOyunlar(){
        List<Fragment> tabs = new ArrayList<>();

        FragmentMain f1 = new FragmentMain();
        Bundle b1 = new Bundle();
        b1.putString("title","Yarış");
        f1.setArguments(b1);
        tabs.add(f1);

        FragmentMain f2 = new FragmentMain();
        Bundle b2 = new Bundle();
        b2.putString("title","Bulmaca");
        f2.setArguments(b2);
        tabs.add(f2);

        FragmentMain f3 = new FragmentMain();
        Bundle b3 = new Bundle();
        b3.putString("title","Aksiyon");
        f3.setArguments(b3);
        tabs.add(f3);

        FragmentMain f4 = new FragmentMain();
        Bundle b4 = new Bundle();
        b4.putString("title","Macera");
        f4.setArguments(b4);
        tabs.add(f4);

        FragmentMain f5 = new FragmentMain();
        Bundle b5 = new Bundle();
        b5.putString("title","Strateji");
        f5.setArguments(b5);
        tabs.add(f5);

        tablariUret(new String[]{"Yarış","Bulmaca","Aksiyon","Macera","Strateji"},tabs);
    }

    public void tabAraclar(){
        List<Fragment> tabs = new ArrayList<>();

        FragmentMain f1 = new FragmentMain();
        Bundle b1 = new Bundle();
        b1.putString("title","Çeviri Hizmetleri");
        f1.setArguments(b1);
        tabs.add(f1);

        FragmentMain f2 = new FragmentMain();
        Bundle b2 = new Bundle();
        b2.putString("title","Barkod Tarayıcı");
        f2.setArguments(b2);
        tabs.add(f2);

        FragmentMain f3 = new FragmentMain();
        Bundle b3 = new Bundle();
        b3.putString("title","Dosya Yöneticisi");
        f3.setArguments(b3);
        tabs.add(f3);

        tablariUret(new String[]{"Çeviri Hizmetleri","Barkod Tarayıcı","Dosya Yöneticisi"},tabs);
    }

    public void tabEglence(){
        List<Fragment> tabs = new ArrayList<>();

        FragmentMain f1 = new FragmentMain();
        Bundle b1 = new Bundle();
        b1.putString("title","Ses/Video");
        f1.setArguments(b1);
        tabs.add(f1);

        FragmentMain f2 = new FragmentMain();
        Bundle b2 = new Bundle();
        b2.putString("title","Fıkralar");
        f2.setArguments(b2);
        tabs.add(f2);

        tablariUret(new String[]{"Ses/Video","Fıkralar"},tabs);
    }



    public void tablariUret(String[] tabs,List<Fragment> tabFragments){
        tabLayout.removeAllTabs();
        for(int i=0; i<tabs.length; i++){
            tabLayout.addTab(tabLayout.newTab().setText(tabs[i]));
        }
        //ViewPager diğer sayfayı gösterirse TabLayout'a haber ver,tab indisini değiştirsin.
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        //Tab'e tıklama olayında, ViewPager Fragment'ın Layout sayfasını göstertsin
        tabLayout.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(viewPager));

        adapter = new TabAdapter(getSupportFragmentManager(),tabFragments);
        viewPager.setAdapter(adapter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        viewPager = findViewById(R.id.viewPager);
        tabLayout = findViewById(R.id.tabLayout);
        tabLayout.setTabMode(TabLayout.MODE_SCROLLABLE);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        tabEgitim();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }



    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_egitim) {
            //icerigiDegistir(new FragmentGenelBakis());
            tabEgitim();
        } else if (id == R.id.nav_eglence) {
            //icerigiDegistir(new FragmentOzelKanallar());
            tabEglence();
        } else if (id == R.id.nav_araclar) {
            //icerigiDegistir(new FragmentURLKanallari());
            tabAraclar();
        } else if (id == R.id.nav_oyunlar) {
            //icerigiDegistir(new FragmentUrunler());
            tabOyunlar();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
