package com.serifgungor.recyclerview_benzersizsatirgoruntusu.Adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.serifgungor.recyclerview_benzersizsatirgoruntusu.Fragment.FragmentKategoriler;
import com.serifgungor.recyclerview_benzersizsatirgoruntusu.Fragment.FragmentKitaplar;
import com.serifgungor.recyclerview_benzersizsatirgoruntusu.Fragment.FragmentYazarlar;

public class TabLayoutAdapter extends FragmentStatePagerAdapter {
    private FragmentManager fm;
    int tabCount;
    public TabLayoutAdapter(FragmentManager fm, int tabCount){
        super(fm);
        this.fm = fm;
        this.tabCount = tabCount;
    }
    @Override
    public Fragment getItem(int position) {
        Fragment fragment=null;
        if(position==0){
            fragment = new FragmentKategoriler();
        }else if(position==1){
            fragment = new FragmentYazarlar();
        }else if(position==2){
            fragment = new FragmentKitaplar();
        }
        return fragment;
    }
    @Override
    public int getCount() {
        return tabCount;
    }
}
