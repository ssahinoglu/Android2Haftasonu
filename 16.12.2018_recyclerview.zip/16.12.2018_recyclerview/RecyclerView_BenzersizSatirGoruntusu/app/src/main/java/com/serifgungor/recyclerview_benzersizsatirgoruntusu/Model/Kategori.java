package com.serifgungor.recyclerview_benzersizsatirgoruntusu.Model;

public class Kategori {
    private int id;
    private String isim;
    private int kitapSayisi;

    public Kategori() {
    }

    public Kategori(int id, String isim, int kitapSayisi) {
        this.id = id;
        this.isim = isim;
        this.kitapSayisi = kitapSayisi;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public int getKitapSayisi() {
        return kitapSayisi;
    }

    public void setKitapSayisi(int kitapSayisi) {
        this.kitapSayisi = kitapSayisi;
    }
}
