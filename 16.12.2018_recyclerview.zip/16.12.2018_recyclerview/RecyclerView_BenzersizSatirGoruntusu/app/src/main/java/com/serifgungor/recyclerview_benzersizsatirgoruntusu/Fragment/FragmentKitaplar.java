package com.serifgungor.recyclerview_benzersizsatirgoruntusu.Fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.serifgungor.recyclerview_benzersizsatirgoruntusu.Adapter.KitapAdapter;
import com.serifgungor.recyclerview_benzersizsatirgoruntusu.Model.Kitap;
import com.serifgungor.recyclerview_benzersizsatirgoruntusu.R;

import java.util.ArrayList;
import java.util.List;

public class FragmentKitaplar extends Fragment {

    RecyclerView recyclerView;
    KitapAdapter adapter;
    List<List<Kitap>> kitaplar;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_kitaplar,null);

        recyclerView = v.findViewById(R.id.recyclerViewKitaplar);

        kitaplar = new ArrayList<>();


        List<Kitap> kitap1 = new ArrayList<>();
        /*
        int kitapId, String kitapAdi, String icerik, String yazarAdSoyad, String turu, String resimUrl, int sayfaSayisi
         */
        kitap1.add(
            new Kitap(
               1,"Kitap 1","içerik","Ad Soyad","Türü","https://i.idefix.com/cache/150x242-0/originals/0001789141001-1.jpg",50
            )
        );
        kitap1.add(
                new Kitap(
                        1,"Kitap 1","içerik","Ad Soyad","Türü","https://i.idefix.com/cache/150x242-0/originals/0001789145001-1.jpg",50
                )
        );
        kitap1.add(
                new Kitap(
                        1,"Kitap 1","içerik","Ad Soyad","Türü","https://i.idefix.com/cache/150x242-0/originals/0001750151001-1.jpg",50
                )
        );
        kitap1.add(
                new Kitap(
                        1,"Kitap 1","içerik","Ad Soyad","Türü","https://i.idefix.com/cache/150x242-0/originals/0001772576001-1.jpg",50
                )
        );
        kitap1.add(
                new Kitap(
                        1,"Kitap 1","içerik","Ad Soyad","Türü","https://i.idefix.com/cache/150x242-0/originals/0001765538001-1.jpg",50
                )
        );
        kitap1.add(
                new Kitap(
                        1,"Kitap 1","içerik","Ad Soyad","Türü","https://i.idefix.com/cache/150x242-0/originals/0001743040001-1.jpg",50
                )
        );


        kitaplar.add(kitap1);
        kitaplar.add(kitap1);



        adapter = new KitapAdapter(kitaplar);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        return v;
    }
}
