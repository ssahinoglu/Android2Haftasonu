package com.serifgungor.recyclerview_benzersizsatirgoruntusu.Adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.serifgungor.recyclerview_benzersizsatirgoruntusu.Holder.KategoriHolder;
import com.serifgungor.recyclerview_benzersizsatirgoruntusu.Model.Kategori;
import com.serifgungor.recyclerview_benzersizsatirgoruntusu.R;

import java.util.List;

public class KategoriAdapter extends RecyclerView.Adapter<KategoriHolder> {
    List<Kategori> kategoris;

    public KategoriAdapter(List<Kategori> kategoris){
        this.kategoris = kategoris;
    }

    @NonNull
    @Override
    public KategoriHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.kategori_view,null);
        return new KategoriHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull KategoriHolder holder, int position) {
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        holder.tvKategoriAdi.setText(kategoris.get(position).getIsim());
        holder.tvKategoriKitapSayisi.setText(""+kategoris.get(position).getKitapSayisi());
    }

    @Override
    public int getItemCount() {
        return kategoris.size();
    }
}
