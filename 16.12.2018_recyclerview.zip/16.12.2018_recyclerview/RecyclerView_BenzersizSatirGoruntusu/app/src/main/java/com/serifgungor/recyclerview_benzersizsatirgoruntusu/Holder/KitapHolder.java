package com.serifgungor.recyclerview_benzersizsatirgoruntusu.Holder;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import com.serifgungor.recyclerview_benzersizsatirgoruntusu.R;

public class KitapHolder extends RecyclerView.ViewHolder {

    public ImageView iv1,iv2,iv3,iv4,iv5,iv6;

    public KitapHolder(View itemView) {
        super(itemView);
        iv1 = itemView.findViewById(R.id.ivPhoto1);
        iv2 = itemView.findViewById(R.id.ivPhoto2);
        iv3 = itemView.findViewById(R.id.ivPhoto3);
        iv4 = itemView.findViewById(R.id.ivPhoto4);
        iv5 = itemView.findViewById(R.id.ivPhoto5);
        iv6 = itemView.findViewById(R.id.ivPhoto6);
    }
}
