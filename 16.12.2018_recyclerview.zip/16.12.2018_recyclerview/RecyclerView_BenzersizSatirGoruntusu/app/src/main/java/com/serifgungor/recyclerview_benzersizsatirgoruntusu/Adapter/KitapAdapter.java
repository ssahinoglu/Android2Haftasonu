package com.serifgungor.recyclerview_benzersizsatirgoruntusu.Adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.serifgungor.recyclerview_benzersizsatirgoruntusu.Holder.KitapHolder;
import com.serifgungor.recyclerview_benzersizsatirgoruntusu.Model.Kitap;
import com.serifgungor.recyclerview_benzersizsatirgoruntusu.R;

import java.util.List;

public class KitapAdapter extends RecyclerView.Adapter<KitapHolder> {

    private List<List<Kitap>> kitaplar;

    public KitapAdapter(){}

    public KitapAdapter(List<List<Kitap>> kitaplar){
        this.kitaplar = kitaplar;
    }

    @NonNull
    @Override
    public KitapHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.kitap_view,null);

        return new KitapHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull KitapHolder holder, int position) {

        List<Kitap> kitap = kitaplar.get(position);

        String url1 = kitap.get(0).getResimUrl();
        String url2 = kitap.get(1).getResimUrl();
        String url3 = kitap.get(2).getResimUrl();
        String url4 = kitap.get(3).getResimUrl();
        String url5 = kitap.get(4).getResimUrl();
        String url6 = kitap.get(5).getResimUrl();

        Glide.with(holder.itemView.getContext())
                .load(url1).into(holder.iv1);

        Glide.with(holder.itemView.getContext())
                .load(url2).into(holder.iv2);

        Glide.with(holder.itemView.getContext())
                .load(url3).into(holder.iv3);

        Glide.with(holder.itemView.getContext())
                .load(url4).into(holder.iv4);

        Glide.with(holder.itemView.getContext())
                .load(url5).into(holder.iv5);

        Glide.with(holder.itemView.getContext())
                .load(url6).into(holder.iv6);


    }

    @Override
    public int getItemCount() {
        return kitaplar.size();
    }
}
