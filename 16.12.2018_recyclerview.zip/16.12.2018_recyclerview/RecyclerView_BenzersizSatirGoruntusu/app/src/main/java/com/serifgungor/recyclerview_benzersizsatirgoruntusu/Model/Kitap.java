package com.serifgungor.recyclerview_benzersizsatirgoruntusu.Model;

public class Kitap {
    private int kitapId;
    private String kitapAdi;
    private String icerik;
    private String yazarAdSoyad;
    private String turu;
    private String resimUrl;
    private int sayfaSayisi;


    public Kitap(int kitapId, String kitapAdi, String icerik, String yazarAdSoyad, String turu, String resimUrl, int sayfaSayisi) {
        this.kitapId = kitapId;
        this.kitapAdi = kitapAdi;
        this.icerik = icerik;
        this.yazarAdSoyad = yazarAdSoyad;
        this.turu = turu;
        this.resimUrl = resimUrl;
        this.sayfaSayisi = sayfaSayisi;
    }

    public Kitap() {
    }

    public int getKitapId() {
        return kitapId;
    }

    public void setKitapId(int kitapId) {
        this.kitapId = kitapId;
    }

    public String getKitapAdi() {
        return kitapAdi;
    }

    public void setKitapAdi(String kitapAdi) {
        this.kitapAdi = kitapAdi;
    }

    public String getIcerik() {
        return icerik;
    }

    public void setIcerik(String icerik) {
        this.icerik = icerik;
    }

    public String getYazarAdSoyad() {
        return yazarAdSoyad;
    }

    public void setYazarAdSoyad(String yazarAdSoyad) {
        this.yazarAdSoyad = yazarAdSoyad;
    }

    public String getTuru() {
        return turu;
    }

    public void setTuru(String turu) {
        this.turu = turu;
    }

    public String getResimUrl() {
        return resimUrl;
    }

    public void setResimUrl(String resimUrl) {
        this.resimUrl = resimUrl;
    }

    public int getSayfaSayisi() {
        return sayfaSayisi;
    }

    public void setSayfaSayisi(int sayfaSayisi) {
        this.sayfaSayisi = sayfaSayisi;
    }
}
