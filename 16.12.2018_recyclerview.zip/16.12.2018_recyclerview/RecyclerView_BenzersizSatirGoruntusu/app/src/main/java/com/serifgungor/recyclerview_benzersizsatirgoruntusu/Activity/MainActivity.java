package com.serifgungor.recyclerview_benzersizsatirgoruntusu.Activity;

import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

import com.serifgungor.recyclerview_benzersizsatirgoruntusu.Adapter.TabLayoutAdapter;
import com.serifgungor.recyclerview_benzersizsatirgoruntusu.R;

public class MainActivity extends AppCompatActivity {

    ViewPager container;
    TabLayout tabLayout;
    TabLayoutAdapter adapter;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        container = findViewById(R.id.container);
        tabLayout = findViewById(R.id.tabs);
        tabLayout.addTab(tabLayout.newTab().setText("Kategoriler"));
        tabLayout.addTab(tabLayout.newTab().setText("Yazarlar"));
        tabLayout.addTab(tabLayout.newTab().setText("Kitaplar"));

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        adapter = new TabLayoutAdapter(getSupportFragmentManager(),tabLayout.getTabCount());
        container.setAdapter(adapter);


        //ViewPager'ın sayfa değiştirme olayında değişikliği Tab'e bildir.
        container.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        //Tab'in indisinin değişme olayında, ViewPager'a bildir.
        tabLayout.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(container));





    }
}
