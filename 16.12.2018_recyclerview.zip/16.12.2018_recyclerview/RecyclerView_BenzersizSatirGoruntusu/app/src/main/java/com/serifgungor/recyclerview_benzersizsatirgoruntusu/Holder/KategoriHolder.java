package com.serifgungor.recyclerview_benzersizsatirgoruntusu.Holder;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.serifgungor.recyclerview_benzersizsatirgoruntusu.R;

public class KategoriHolder extends RecyclerView.ViewHolder {

    public TextView tvKategoriAdi;
    public TextView tvKategoriKitapSayisi;

    public KategoriHolder(View itemView) {
        super(itemView);
        tvKategoriAdi = itemView.findViewById(R.id.tvKategoriAdi);
        tvKategoriKitapSayisi = itemView.findViewById(R.id.tvKategoriKitapSayisi);
    }

}
