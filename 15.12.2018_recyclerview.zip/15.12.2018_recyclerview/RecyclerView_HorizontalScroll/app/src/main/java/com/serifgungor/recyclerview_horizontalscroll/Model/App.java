package com.serifgungor.recyclerview_horizontalscroll.Model;

public class App {
    private int id;
    private String name;
    private String photourl;
    private String developer;
    private double point;

    public App() {
    }

    public App(int id, String name, String photourl, String developer, double point) {
        this.id = id;
        this.name = name;
        this.photourl = photourl;
        this.developer = developer;
        this.point = point;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhotourl() {
        return photourl;
    }

    public void setPhotourl(String photourl) {
        this.photourl = photourl;
    }

    public String getDeveloper() {
        return developer;
    }

    public void setDeveloper(String developer) {
        this.developer = developer;
    }

    public double getPoint() {
        return point;
    }

    public void setPoint(double point) {
        this.point = point;
    }
}
