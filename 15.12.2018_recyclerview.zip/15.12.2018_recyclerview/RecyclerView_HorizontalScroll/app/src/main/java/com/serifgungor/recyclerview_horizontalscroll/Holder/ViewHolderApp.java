package com.serifgungor.recyclerview_horizontalscroll.Holder;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.serifgungor.recyclerview_horizontalscroll.R;

public class ViewHolderApp extends RecyclerView.ViewHolder {

    public ImageView ivLogo;
    public TextView tvTitle,tvDeveloper,tvPoint;

    public ViewHolderApp(View itemView) {
        super(itemView);
        ivLogo = itemView.findViewById(R.id.ivAppLogo);
        tvTitle = itemView.findViewById(R.id.tvAppTitle);
        tvDeveloper = itemView.findViewById(R.id.tvDeveloper);
        tvPoint = itemView.findViewById(R.id.tvPoint);
    }
}
